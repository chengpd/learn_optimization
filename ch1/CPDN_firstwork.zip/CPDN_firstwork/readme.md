# 第一次作业



由于用的是ubunt 18.04使用的是cmake工程

该文件夹 由cpp文件和cmake 文件构成

编译及执行代码

```
mkdir build
cd build
cmake ..
make
./line
```



采用的函数是：
$$
f(x,y)=(1-x^2)+100(y-x^2)^2
$$




x的梯度值： $grad_x = 400* x^3 + (2-400y)x-2;$

y的梯度值：  $    grad_y = 200*(y-x^2);$



![image-20221007205928861](/home/cp/.config/Typora/typora-user-images/image-20221007205928861.png)



数据解释（从左到右）

执行次数 上一次函数值 本次函数值 本次 x 的梯度值  本次 y 的梯度值 x的值 y的值

最后一行为执行时间
